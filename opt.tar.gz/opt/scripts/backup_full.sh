#!/bin/bash

#Vericicacion de opciones y ayuda
if [[ "$1" == "-h" ]]; then
    echo "Uso: $0 ORIGEN DESTINO"
    echo "ORIGEN: Directorio a respaldar (ej: /etc, /var/logs, /www_dir)"
    echo "DESTINO: Directorio donde se guardará el resguardo (ej: /backup_dir)"
    exit 0
fi

# Verificacion de argumentos
if [ $# -ne 2 ]; then
    echo "Error: Se deben especificar los dos directorios (ORIGEN y DESTINO)."
    exit 1
fi

# Asignnar variables de origen y destino
ORIGEN=$1
DESTINO=$2

# Verificar si existen los directorios
if [ ! -d "$ORIGEN" ]; then
    echo "Error: El directorio de origen '$ORIGEN' no existe."
    exit 1
fi

if [ ! -d "$DESTINO" ]; then
    echo "Error: El directorio de destino '$DESTINO' no existe."
    exit 1
fi

# Fecha actual en formato ANSI
FECHA=$(date +%Y%m%d)

# Nombre del archivo de backup
NOMBRE_BACKUP=$(basename "$ORIGEN")_bkp_$FECHA.tar.gz

# Crear el backup usando tar
echo "Realizando backup de '$ORIGEN' a '$DESTINO/$NOMBRE_BACKUP'..."
tar -czf "$DESTINO/$NOMBRE_BACKUP" -C "$ORIGEN" .

# Verificar si el backup fue exitoso
if [ $? -eq 0 ]; then
    echo "Backup exitoso: '$DESTINO/$NOMBRE_BACKUP'"
else
    echo "Error al realizar el backup."
    exit 1
fi
